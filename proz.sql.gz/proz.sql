-- phpMyAdmin SQL Dump
-- version 4.0.10.20
-- https://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 10, 2019 at 06:50 PM
-- Server version: 5.5.25
-- PHP Version: 5.3.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `proz`
--

-- --------------------------------------------------------

--
-- Table structure for table `account_type`
--

DROP TABLE IF EXISTS `account_type`;
CREATE TABLE IF NOT EXISTS `account_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_type_id` int(11) NOT NULL,
  `account_type_name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `account_type_id` (`account_type_id`,`account_type_name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `account_type`
--

INSERT INTO `account_type` (`id`, `account_type_id`, `account_type_name`) VALUES
(2, 1, 'Translation agency/company'),
(1, 2, 'Freelance translator and/or interpreter'),
(3, 3, 'Freelancer and outsourcer'),
(7, 4, 'Other'),
(4, 5, 'Student'),
(5, 6, 'End customer'),
(6, 8, 'Vendor/advertiser to the translation industry');

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

DROP TABLE IF EXISTS `countries`;
CREATE TABLE IF NOT EXISTS `countries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `country_code` varchar(255) NOT NULL,
  `country_name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `country_code` (`country_code`,`country_name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=244 ;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES
(5, 'ad', 'Andorra'),
(227, 'ae', 'United Arab Emirates'),
(1, 'af', 'Afghanistan'),
(9, 'ag', 'Antigua Barbuda'),
(7, 'ai', 'Anguilla'),
(2, 'al', 'Albania'),
(11, 'am', 'Armenia'),
(149, 'an', 'Neth. Antilles'),
(6, 'ao', 'Angola'),
(8, 'aq', 'Antarctica'),
(10, 'ar', 'Argentina'),
(4, 'as', 'American Samoa'),
(14, 'at', 'Austria'),
(13, 'au', 'Australia'),
(12, 'aw', 'Aruba'),
(15, 'az', 'Azerbaijan'),
(27, 'ba', 'Bosnia and Herzegovina'),
(19, 'bb', 'Barbados'),
(18, 'bd', 'Bangladesh'),
(21, 'be', 'Belgium'),
(34, 'bf', 'Burkina Faso'),
(33, 'bg', 'Bulgaria'),
(17, 'bh', 'Bahrain'),
(35, 'bi', 'Burundi'),
(23, 'bj', 'Benin'),
(24, 'bm', 'Bermuda'),
(32, 'bn', 'Brunei Darussalam'),
(26, 'bo', 'Bolivia'),
(31, 'br', 'Brazil'),
(16, 'bs', 'Bahamas'),
(25, 'bt', 'Bhutan'),
(29, 'bv', 'Bouvet Island'),
(28, 'bw', 'Botswana'),
(20, 'by', 'Belarus'),
(22, 'bz', 'Belize'),
(38, 'ca', 'Canada'),
(46, 'cc', 'Cocos (Keeling) Isl.'),
(41, 'cf', 'Centr. African Republic'),
(49, 'cg', 'Congo'),
(210, 'ch', 'Switzerland'),
(53, 'ci', 'Cote D''ivoire'),
(51, 'ck', 'Cook Islands'),
(43, 'cl', 'Chile'),
(37, 'cm', 'Cameroon'),
(44, 'cn', 'China'),
(47, 'co', 'Colombia'),
(52, 'cr', 'Costa Rica'),
(55, 'cu', 'Cuba'),
(39, 'cv', 'Cape Verde'),
(45, 'cx', 'Christmas Island'),
(56, 'cy', 'Cyprus'),
(57, 'cz', 'Czech Republic'),
(81, 'de', 'Germany'),
(59, 'dj', 'Djibouti'),
(58, 'dk', 'Denmark'),
(60, 'dm', 'Dominica'),
(61, 'do', 'Dominican Republic'),
(3, 'dz', 'Algeria'),
(63, 'ec', 'Ecuador'),
(68, 'ee', 'Estonia'),
(64, 'eg', 'Egypt'),
(240, 'eh', 'Western Sahara'),
(67, 'er', 'Eritrea'),
(200, 'es', 'Spain'),
(69, 'et', 'Ethiopia'),
(73, 'fi', 'Finland'),
(72, 'fj', 'Fiji'),
(70, 'fk', 'Falkland Islands'),
(137, 'fm', 'Micronesia'),
(71, 'fo', 'Faroe Islands'),
(75, 'fr', 'France'),
(78, 'ga', 'Gabon'),
(228, 'gb', 'United Kingdom'),
(86, 'gd', 'Grenada'),
(80, 'ge', 'Georgia'),
(76, 'gf', 'French Guiana'),
(82, 'gh', 'Ghana'),
(83, 'gi', 'Gibraltar'),
(85, 'gl', 'Greenland'),
(79, 'gm', 'Gambia'),
(90, 'gn', 'Guinea'),
(87, 'gp', 'Guadeloupe'),
(66, 'gq', 'Equatorial Guinea'),
(84, 'gr', 'Greece'),
(181, 'gs', 'S Georgia, Sandwich'),
(89, 'gt', 'Guatemala'),
(88, 'gu', 'Guam'),
(91, 'gw', 'Guinea-bissau'),
(92, 'gy', 'Guyana'),
(96, 'hk', 'Hong Kong'),
(94, 'hm', 'Heard, McDonald Isl.'),
(95, 'hn', 'Honduras'),
(54, 'hr', 'Croatia'),
(93, 'ht', 'Haiti'),
(97, 'hu', 'Hungary'),
(100, 'id', 'Indonesia'),
(103, 'ie', 'Ireland'),
(104, 'il', 'Israel'),
(99, 'in', 'India'),
(30, 'io', 'Br. Indian Ocean Terr.'),
(102, 'iq', 'Iraq'),
(101, 'ir', 'Iran'),
(98, 'is', 'Iceland'),
(105, 'it', 'Italy'),
(106, 'jm', 'Jamaica'),
(108, 'jo', 'Jordan'),
(107, 'jp', 'Japan'),
(110, 'ke', 'Kenya'),
(113, 'kg', 'Kyrgyzstan'),
(36, 'kh', 'Cambodia'),
(111, 'ki', 'Kiribati'),
(48, 'km', 'Comoros'),
(182, 'kn', 'Saint Kitts, Nevis'),
(159, 'kp', 'North Korea'),
(199, 'kr', 'South Korea'),
(112, 'kw', 'Kuwait'),
(40, 'ky', 'Cayman Islands'),
(109, 'kz', 'Kazakhstan'),
(114, 'la', 'Laos'),
(116, 'lb', 'Lebanon'),
(183, 'lc', 'Saint Lucia'),
(120, 'li', 'Liechtenstein'),
(201, 'lk', 'Sri Lanka'),
(118, 'lr', 'Liberia'),
(117, 'ls', 'Lesotho'),
(121, 'lt', 'Lithuania'),
(122, 'lu', 'Luxembourg'),
(115, 'lv', 'Latvia'),
(119, 'ly', 'Libya'),
(143, 'ma', 'Morocco'),
(139, 'mc', 'Monaco'),
(138, 'md', 'Moldova'),
(141, 'me', 'Montenegro'),
(125, 'mg', 'Madagascar'),
(131, 'mh', 'Marshall Islands'),
(124, 'mk', 'Macedonia (FYROM)'),
(129, 'ml', 'Mali'),
(145, 'mm', 'Myanmar'),
(140, 'mn', 'Mongolia'),
(123, 'mo', 'Macau'),
(160, 'mp', 'North Mariana Isl.'),
(132, 'mq', 'Martinique'),
(133, 'mr', 'Mauritania'),
(142, 'ms', 'Montserrat'),
(130, 'mt', 'Malta'),
(134, 'mu', 'Mauritius'),
(128, 'mv', 'Maldives'),
(126, 'mw', 'Malawi'),
(136, 'mx', 'Mexico'),
(127, 'my', 'Malaysia'),
(144, 'mz', 'Mozambique'),
(146, 'na', 'Namibia'),
(152, 'nc', 'New Caledonia'),
(155, 'ne', 'Niger'),
(158, 'nf', 'Norfolk Island'),
(156, 'ng', 'Nigeria'),
(154, 'ni', 'Nicaragua'),
(150, 'nl', 'Netherlands'),
(161, 'no', 'Norway'),
(148, 'np', 'Nepal'),
(147, 'nr', 'Nauru'),
(157, 'nu', 'Niue'),
(153, 'nz', 'New Zealand'),
(162, 'om', 'Oman'),
(167, 'pa', 'Panama'),
(170, 'pe', 'Peru'),
(77, 'pf', 'French Polynesia'),
(168, 'pg', 'Papua New Guinea'),
(171, 'ph', 'Philippines'),
(164, 'pk', 'Pakistan'),
(173, 'pl', 'Poland'),
(204, 'pm', 'St. Pierre, Miquelon'),
(172, 'pn', 'Pitcairn'),
(175, 'pr', 'Puerto Rico'),
(166, 'ps', 'Palestine'),
(174, 'pt', 'Portugal'),
(165, 'pw', 'Palau'),
(169, 'py', 'Paraguay'),
(176, 'qa', 'Qatar'),
(177, 're', 'Reunion'),
(178, 'ro', 'Romania'),
(189, 'rs', 'Serbia'),
(179, 'ru', 'Russian Federation'),
(180, 'rw', 'Rwanda'),
(187, 'sa', 'Saudi Arabia'),
(196, 'sb', 'Solomon Islands'),
(191, 'sc', 'Seychelles'),
(205, 'sd', 'Sudan'),
(209, 'se', 'Sweden'),
(193, 'sg', 'Singapore'),
(203, 'sh', 'St. Helena'),
(195, 'si', 'Slovenia'),
(207, 'sj', 'Svalbard, Jan Mayen'),
(194, 'sk', 'Slovakia'),
(192, 'sl', 'Sierra Leone'),
(185, 'sm', 'San Marino'),
(188, 'sn', 'Senegal'),
(197, 'so', 'Somalia'),
(206, 'sr', 'Suriname'),
(186, 'st', 'Sao Tome, Principe'),
(65, 'sv', 'El Salvador'),
(211, 'sy', 'Syria'),
(208, 'sz', 'Swaziland'),
(223, 'tc', 'Turks, Caicos Isl.'),
(42, 'td', 'Chad'),
(74, 'tf', 'Fr. Southern Terr.'),
(216, 'tg', 'Togo'),
(215, 'th', 'Thailand'),
(213, 'tj', 'Tajikistan'),
(217, 'tk', 'Tokelau'),
(222, 'tm', 'Turkmenistan'),
(220, 'tn', 'Tunisia'),
(218, 'to', 'Tonga'),
(62, 'tp', 'East Timor'),
(221, 'tr', 'Turkey'),
(219, 'tt', 'Trinidad and Tobago'),
(224, 'tv', 'Tuvalu'),
(212, 'tw', 'Taiwan'),
(214, 'tz', 'Tanzania'),
(226, 'ua', 'Ukraine'),
(225, 'ug', 'Uganda'),
(231, 'um', 'US Minor Outlying Isl.'),
(229, 'us', 'United States'),
(230, 'uy', 'Uruguay'),
(232, 'uz', 'Uzbekistan'),
(234, 'va', 'Vatican City State'),
(202, 'vc', 'St Vincent, Grenadines'),
(235, 've', 'Venezuela'),
(237, 'vg', 'Virgin Islands (British)'),
(238, 'vi', 'Virgin Islands (U.S.)'),
(236, 'vn', 'Vietnam'),
(233, 'vu', 'Vanuatu'),
(239, 'wf', 'Wallis, Futuna Isl.'),
(184, 'ws', 'Samoa'),
(151, 'xx', 'Neutral Zone'),
(241, 'ye', 'Yemen'),
(135, 'yt', 'Mayotte'),
(190, 'yu', 'Serbia and Montenegro'),
(198, 'za', 'South Africa'),
(242, 'zm', 'Zambia'),
(50, 'zr', 'Congo, Democratic Republic'),
(243, 'zw', 'Zimbabwe'),
(163, 'zz', 'Other');

-- --------------------------------------------------------

--
-- Table structure for table `currencies`
--

DROP TABLE IF EXISTS `currencies`;
CREATE TABLE IF NOT EXISTS `currencies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `currency_code` varchar(255) NOT NULL,
  `currency_name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `currency_code` (`currency_code`,`currency_name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=167 ;

--
-- Dumping data for table `currencies`
--

INSERT INTO `currencies` (`id`, `currency_code`, `currency_name`) VALUES
(1, 'aed', 'U.A.E. dirhams'),
(2, 'afn', 'Afghani'),
(3, 'all', 'Lek'),
(4, 'amd', 'Armenian Dram'),
(5, 'ang', 'Netherlands Antillean Guilder'),
(6, 'aoa', 'Kwanza'),
(7, 'ars', 'Argentine pesos'),
(8, 'aud', 'Australian dollars'),
(9, 'awg', 'Aruban Florin'),
(10, 'azn', 'Azerbaijan Manat'),
(11, 'bam', 'Bosnian Convertible Mark'),
(12, 'bbd', 'Barbadian Dollar'),
(13, 'bdt', 'Bangladesh taka'),
(14, 'bgn', 'Bulgaria Leva'),
(15, 'bhd', 'Bahrain dinars'),
(16, 'bif', 'Burundi Franc'),
(17, 'bmd', 'Bermudian Dollar'),
(18, 'bnd', 'Brunei dollar'),
(19, 'bob', 'Boliviano'),
(20, 'bov', 'Mvdol'),
(21, 'brl', 'Brazilian reais'),
(22, 'bsd', 'Bahamian Dollar'),
(23, 'btn', 'Ngultrum'),
(24, 'bwp', 'Botswana pula'),
(25, 'byn', 'Belarusian Ruble'),
(26, 'bzd', 'Belize Dollar'),
(27, 'cad', 'Canadian dollars'),
(28, 'cdf', 'Congolese Franc'),
(29, 'che', 'WIR Euro'),
(30, 'chf', 'Swiss francs'),
(31, 'chw', 'WIR Franc'),
(32, 'clf', 'Unidad de Fomento'),
(33, 'clp', 'Chilean pesos'),
(34, 'cny', 'Chinese yuan'),
(35, 'cop', 'Colombian pesos'),
(36, 'cou', 'Unidad de Valor Real'),
(37, 'crc', 'Colón'),
(38, 'cuc', 'Peso Convertible'),
(39, 'cup', 'Cuban Peso'),
(40, 'cve', 'Cabo Verde Escudo'),
(41, 'cyp', 'Cyprus pounds'),
(42, 'czk', 'Czech koruny'),
(43, 'djf', 'Djibouti Franc'),
(44, 'dkk', 'Danish kroner'),
(45, 'dop', 'Dominican peso'),
(46, 'dzd', 'Algerian Dinar'),
(47, 'eek', 'Estonian krooni'),
(48, 'egp', 'Egyptian pounds'),
(49, 'ern', 'Nakfa'),
(50, 'etb', 'Ethiopian Birr'),
(51, 'eur', 'Euro'),
(52, 'fjd', 'Fiji Dollar'),
(53, 'fkp', 'Falkland Islands Pound'),
(54, 'gbp', 'Pounds sterling'),
(55, 'gel', 'Lari'),
(56, 'ghs', 'Ghana Cedi'),
(57, 'gip', 'Gibraltar Pound'),
(58, 'gmd', 'Dalasi'),
(59, 'gnf', 'Guinean Franc'),
(60, 'gtq', 'Quetzal'),
(61, 'gyd', 'Guyana Dollar'),
(62, 'hkd', 'Hong Kong dollars'),
(63, 'hnl', 'Lempira'),
(64, 'hrk', 'Croatian Kuna'),
(65, 'htg', 'Gourde'),
(66, 'huf', 'Hungarian forint'),
(67, 'idr', 'Indonesian rupiah'),
(68, 'ils', 'Israel shekels'),
(69, 'inr', 'Indian rupees'),
(70, 'iqd', 'Iraqi dinars'),
(71, 'irr', 'Iranian rials'),
(72, 'isk', 'Icelandic kronur'),
(73, 'jmd', 'Jamaican dollar'),
(74, 'jod', 'Jordanian Dinar'),
(75, 'jpy', 'Japanese yen'),
(76, 'kes', 'Kenyan shilling'),
(77, 'kgs', 'Som'),
(78, 'khr', 'Riel'),
(79, 'kmf', 'Comorian Franc'),
(80, 'kpw', 'North Korean Won'),
(81, 'krw', 'Korean won'),
(82, 'kwd', 'Kuwaiti dinars'),
(83, 'kyd', 'Cayman Islands Dollar'),
(84, 'kzt', 'Tenge'),
(85, 'lak', 'Lao Kip'),
(86, 'lbp', 'Lebanese Pound'),
(87, 'lkr', 'Sri Lanka rupees'),
(88, 'lrd', 'Liberian Dollar'),
(89, 'lsl', 'Loti'),
(90, 'lvl', 'Latvian lati'),
(91, 'lyd', 'Libyan dinars'),
(92, 'mad', 'Moroccan dirham'),
(93, 'mdl', 'Moldovan Leu'),
(94, 'mga', 'Malagasy Ariary'),
(95, 'mkd', 'Macedonian Denars'),
(96, 'mmk', 'Kyat'),
(97, 'mnt', 'Mongolian Tugriks'),
(98, 'mop', 'Macau pataca'),
(99, 'mru', 'Ouguiya'),
(100, 'mtl', 'Maltese liri'),
(101, 'mur', 'Mauritius Rupee'),
(102, 'mvr', 'Rufiyaa'),
(103, 'mwk', 'Malawi Kwacha'),
(104, 'mxn', 'Mexican pesos'),
(105, 'mxv', 'Mexican Unidad de Inversion (UDI)'),
(106, 'myr', 'Malaysian ringgit'),
(107, 'mzn', 'Mozambique Metical'),
(108, 'nad', 'Namibia Dollar'),
(109, 'ngn', 'Naira'),
(110, 'nio', 'Cordoba Oro'),
(111, 'nok', 'Norwegian kroner'),
(112, 'npr', 'Nepalese rupees'),
(113, 'nzd', 'New Zealand dollars'),
(114, 'omr', 'Omani rials'),
(115, 'pab', 'Balboa'),
(116, 'pen', 'Peruvian nuevo sol'),
(117, 'pgk', 'Kina'),
(118, 'php', 'Philippine Pesos'),
(119, 'pkr', 'Pakistan rupees'),
(120, 'pln', 'Polish zlotys'),
(121, 'pyg', 'Guarani'),
(122, 'qar', 'Qatar riyals'),
(123, 'ron', 'Romanian new lei'),
(124, 'rsd', 'Serbian dinars'),
(125, 'rub', 'Russian rubles'),
(126, 'rwf', 'Rwanda Franc'),
(127, 'sar', 'Saudi Arabian riyals'),
(128, 'sbd', 'Solomon Islands Dollar'),
(129, 'scr', 'Seychelles Rupee'),
(130, 'sdg', 'Sudanese Pound'),
(131, 'sek', 'Swedish kronor'),
(132, 'sgd', 'Singapore dollars'),
(133, 'shp', 'Saint Helena Pound'),
(134, 'sit', 'Slovenian tolars'),
(135, 'sll', 'Leone'),
(136, 'sos', 'Somali Shilling'),
(137, 'srd', 'Surinam Dollar'),
(138, 'ssp', 'South Sudanese Pound'),
(139, 'stn', 'Dobra'),
(140, 'svc', 'El Salvador Colon'),
(141, 'syp', 'Syrian pound'),
(142, 'szl', 'Lilangeni'),
(143, 'thb', 'Thai baht'),
(144, 'tjs', 'Tajikistan Somoni'),
(145, 'tmt', 'Turkmenistan New Manat'),
(146, 'tnd', 'Tunisian Dinar'),
(147, 'top', 'Pa’anga'),
(148, 'try', 'Turkish Lira'),
(149, 'ttd', 'Trinidad & Tobago dollars'),
(150, 'twd', 'New Taiwan dollar'),
(151, 'tzs', 'Tanzanian Shilling'),
(152, 'uah', 'Ukrainian hrvnia'),
(153, 'ugx', 'Uganda Shilling'),
(154, 'usd', 'U. S. dollars'),
(155, 'uyi', 'Uruguay Peso en Unidades Indexadas (UI)'),
(156, 'uyu', 'Uruguayan pesos'),
(157, 'uzs', 'Uzbekistan Sum'),
(158, 'veb', 'Venezuelan bolivares'),
(159, 'vef', 'Bolívar'),
(160, 'vnd', 'Vietnamese dong'),
(161, 'vuv', 'Vatu'),
(162, 'wst', 'Tala'),
(163, 'yer', 'Yemeni Rial'),
(164, 'zar', 'South African rand'),
(165, 'zmw', 'Zambian Kwacha'),
(166, 'zwl', 'Zimbabwe Dollar');

-- --------------------------------------------------------

--
-- Table structure for table `document_types`
--

DROP TABLE IF EXISTS `document_types`;
CREATE TABLE IF NOT EXISTS `document_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type_code` varchar(255) NOT NULL,
  `type_name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `type_code` (`type_code`,`type_name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `document_types`
--

INSERT INTO `document_types` (`id`, `type_code`, `type_name`) VALUES
(7, 'dtp', 'DTP Package'),
(5, 'framemkr', 'Framemaker'),
(11, 'hardcopy', 'Hardcopy (paper, fax, etc.)'),
(10, 'image', 'Image/graphic'),
(3, 'msexcel', 'Microsoft Excel'),
(2, 'mspoint', 'Microsoft Powerpoint'),
(1, 'msword', 'Microsoft Word'),
(8, 'mult', 'Multiple formats'),
(14, 'other', 'None of the above'),
(9, 'pdf', 'PDF document'),
(6, 'pgmkr', 'Pagemaker'),
(4, 'tagged', 'Tagged format (HTML, XML, etc.)'),
(12, 'txt', 'Plain text file'),
(13, 'unknown', 'Format not known');

-- --------------------------------------------------------

--
-- Table structure for table `freelancer`
--

DROP TABLE IF EXISTS `freelancer`;
CREATE TABLE IF NOT EXISTS `freelancer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `site_name` varchar(255) NOT NULL,
  `account_type` int(11) NOT NULL,
  `profile_url` varchar(255) NOT NULL,
  `image_url` varchar(255) NOT NULL,
  `tagline` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `middle_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `country_code` varchar(255) NOT NULL,
  `timezone` varchar(255) NOT NULL,
  `lat` varchar(255) NOT NULL,
  `lng` varchar(255) NOT NULL,
  `street_line_1` varchar(255) NOT NULL,
  `street_line_2` varchar(255) NOT NULL,
  `street_line_3` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `region` varchar(255) NOT NULL,
  `postal` varchar(255) NOT NULL,
  `skype` varchar(255) NOT NULL,
  `twitter` varchar(255) NOT NULL,
  `website` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `freelancer_cpn_certification`
--

DROP TABLE IF EXISTS `freelancer_cpn_certification`;
CREATE TABLE IF NOT EXISTS `freelancer_cpn_certification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `pair_code` varchar(255) NOT NULL,
  `certificate_url` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `freelancer_cpn_certifications`
--

DROP TABLE IF EXISTS `freelancer_cpn_certifications`;
CREATE TABLE IF NOT EXISTS `freelancer_cpn_certifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `cpn_certifications` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `freelancer_credentials`
--

DROP TABLE IF EXISTS `freelancer_credentials`;
CREATE TABLE IF NOT EXISTS `freelancer_credentials` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `pair_code` varchar(255) NOT NULL,
  `authority` varchar(255) NOT NULL,
  `verified` varchar(255) NOT NULL,
  `certificate_url` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `freelancer_general_disciplines`
--

DROP TABLE IF EXISTS `freelancer_general_disciplines`;
CREATE TABLE IF NOT EXISTS `freelancer_general_disciplines` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `disc_gen_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `freelancer_general_services`
--

DROP TABLE IF EXISTS `freelancer_general_services`;
CREATE TABLE IF NOT EXISTS `freelancer_general_services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `gen_service_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `freelancer_language_pairs`
--

DROP TABLE IF EXISTS `freelancer_language_pairs`;
CREATE TABLE IF NOT EXISTS `freelancer_language_pairs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `pair_code` varchar(255) NOT NULL,
  `pair_name` varchar(255) NOT NULL,
  `services` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `freelancer_language_services`
--

DROP TABLE IF EXISTS `freelancer_language_services`;
CREATE TABLE IF NOT EXISTS `freelancer_language_services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `service_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `freelancer_native_language`
--

DROP TABLE IF EXISTS `freelancer_native_language`;
CREATE TABLE IF NOT EXISTS `freelancer_native_language` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `native_language` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `freelancer_qualifications`
--

DROP TABLE IF EXISTS `freelancer_qualifications`;
CREATE TABLE IF NOT EXISTS `freelancer_qualifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `cv_url` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `freelancer_software`
--

DROP TABLE IF EXISTS `freelancer_software`;
CREATE TABLE IF NOT EXISTS `freelancer_software` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `software` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `freelancer_specific_disciplines`
--

DROP TABLE IF EXISTS `freelancer_specific_disciplines`;
CREATE TABLE IF NOT EXISTS `freelancer_specific_disciplines` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `disc_spec_id` int(11) NOT NULL,
  `expertise_level` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `general_disciplines`
--

DROP TABLE IF EXISTS `general_disciplines`;
CREATE TABLE IF NOT EXISTS `general_disciplines` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `disc_gen_id` int(11) NOT NULL,
  `disc_gen_name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `disc_gen_id` (`disc_gen_id`,`disc_gen_name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `general_disciplines`
--

INSERT INTO `general_disciplines` (`id`, `disc_gen_id`, `disc_gen_name`) VALUES
(1, 1, 'Tech/Engineering'),
(2, 2, 'Art/Literary'),
(3, 3, 'Medical'),
(4, 4, 'Law/Patents'),
(5, 5, 'Science'),
(6, 6, 'Bus/Financial'),
(7, 7, 'Marketing'),
(8, 8, 'Other'),
(9, 9, 'Social Sciences');

-- --------------------------------------------------------

--
-- Table structure for table `general_service`
--

DROP TABLE IF EXISTS `general_service`;
CREATE TABLE IF NOT EXISTS `general_service` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gen_service_id` int(11) NOT NULL,
  `gen_service_name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `gen_service_id` (`gen_service_id`,`gen_service_name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `general_service`
--

INSERT INTO `general_service` (`id`, `gen_service_id`, `gen_service_name`) VALUES
(1, 1, 'Translation'),
(2, 2, 'Interpreting'),
(3, 3, 'Editing/proofreading'),
(4, 4, 'Website localization'),
(5, 5, 'Software localization'),
(6, 6, 'Voiceover (dubbing)'),
(7, 7, 'Subtitling'),
(10, 8, 'Training'),
(11, 9, 'Desktop publishing'),
(12, 10, 'Project management'),
(13, 11, 'Vendor management'),
(14, 12, 'Sales'),
(15, 13, 'Operations management'),
(8, 14, 'MT post-editing'),
(9, 15, 'Transcription'),
(16, 16, 'Copywriting'),
(17, 19, 'Transcreation');

-- --------------------------------------------------------

--
-- Table structure for table `languages`
--

DROP TABLE IF EXISTS `languages`;
CREATE TABLE IF NOT EXISTS `languages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `language_code` varchar(255) NOT NULL,
  `language_name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `language_code` (`language_code`,`language_name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=472 ;

--
-- Dumping data for table `languages`
--

INSERT INTO `languages` (`id`, `language_code`, `language_name`) VALUES
(57, '.br', 'Brahui'),
(78, '.ci', 'Chin'),
(72, '.cm', 'Cham'),
(105, '.dd', 'Dida'),
(100, '.dm', 'Damara'),
(103, '.dy', 'Dayak'),
(136, '.fl', 'Flemish'),
(145, '.fu', 'Fulani'),
(138, '.fw', 'Formosan'),
(179, '.ik', 'I-kiribati'),
(85, '.im', 'Cook Island Maori'),
(207, '.kd', 'Kadazan'),
(229, '.kl', 'Klingon'),
(219, '.ky', 'Kayah'),
(285, '.mb', 'Mbundu'),
(287, '.me', 'Meo'),
(289, '.mi', 'Miao'),
(298, '.mk', 'Mordvinian'),
(301, '.mu', 'Muong'),
(311, '.ni', 'Nigerian'),
(333, '.ov', 'Ovambo'),
(384, '.se', 'Simple English'),
(382, '.sg', 'Sign Language'),
(394, '.sx', 'Somba'),
(412, '.tm', 'Tamang'),
(436, '.tv', 'Tuvaluan'),
(448, '.va', 'Valencia'),
(464, '.yi', 'Yi'),
(442, '.yq', 'Ulithian'),
(458, '.ys', 'Woleaian'),
(5, 'aar', 'Afar'),
(1, 'abk', 'Abkhazian'),
(2, 'ace', 'Achinese'),
(3, 'ach', 'Acoli'),
(4, 'ada', 'Adangme'),
(8, 'afa', 'Afro-Asiatic (Other)'),
(6, 'afh', 'Afrihili'),
(7, 'afr', 'Afrikaans'),
(9, 'aka', 'Akan'),
(10, 'akk', 'Akkadian'),
(12, 'ale', 'Aleut'),
(13, 'alg', 'Algonquian languages'),
(15, 'amh', 'Amharic'),
(121, 'ang', 'English Old (ca.450-1100)'),
(17, 'apa', 'Apache languages'),
(18, 'ara', 'Arabic'),
(19, 'arc', 'Aramaic'),
(21, 'arn', 'Araucanian'),
(20, 'arp', 'Arapaho'),
(24, 'art', 'Artificial(Other)'),
(22, 'arw', 'Arawak'),
(25, 'asm', 'Assamese'),
(26, 'ast', 'Asturian'),
(27, 'ath', 'Athapascan languages'),
(29, 'ava', 'Avaric'),
(30, 'ave', 'Avestan'),
(31, 'awa', 'Awadhi'),
(32, 'aym', 'Aymara'),
(33, 'aze', 'Azerbaijani'),
(40, 'bad', 'Banda'),
(39, 'bai', 'Bamilekelanguages'),
(43, 'bak', 'Bashkir'),
(37, 'bal', 'Baluchi'),
(38, 'bam', 'Bambara'),
(35, 'ban', 'Balinese'),
(42, 'bas', 'Basa'),
(36, 'bat', 'Baltic languages'),
(34, 'bba', 'Baatonum'),
(45, 'bej', 'Beja'),
(46, 'bel', 'Belarusian'),
(47, 'bem', 'Bemba'),
(48, 'ben', 'Bengali'),
(49, 'ber', 'Berber (Other)'),
(50, 'bho', 'Bhojpuri (& Tharu)'),
(51, 'bih', 'Bihari'),
(52, 'bik', 'Bikol'),
(53, 'bin', 'Bini'),
(54, 'bis', 'Bislama'),
(383, 'bla', 'Siksika'),
(41, 'bnt', 'Bantu(Other)'),
(420, 'bod', 'Tibetan'),
(56, 'bos', 'Bosnian'),
(58, 'bra', 'Braj'),
(59, 'bre', 'Breton'),
(62, 'bua', 'Buriat'),
(60, 'bug', 'Buginese'),
(61, 'bul', 'Bulgarian'),
(64, 'cad', 'Caddo'),
(70, 'cai', 'Central American Indian (Other)'),
(65, 'car', 'Carib'),
(66, 'cat', 'Catalan'),
(67, 'cau', 'Caucasian(Other)'),
(68, 'ceb', 'Cebuano (Bisayan)'),
(69, 'cel', 'Celtic(Other)'),
(97, 'ces', 'Czech'),
(73, 'cha', 'Chamorro'),
(77, 'chb', 'Chibcha'),
(74, 'che', 'Chechen'),
(71, 'chg', 'Chagatai'),
(83, 'chk', 'Chuukese'),
(280, 'chm', 'Mari'),
(80, 'chn', 'Chinookjargon'),
(81, 'cho', 'Choctaw'),
(75, 'chr', 'Cherokee'),
(82, 'chu', 'Church Slavonic'),
(84, 'chv', 'Chuvash'),
(76, 'chy', 'Cheyenne'),
(86, 'cop', 'Coptic'),
(87, 'cor', 'Cornish'),
(88, 'cos', 'Corsican'),
(91, 'cpe', 'Creoles & Pidgins (English-based Other)'),
(92, 'cpf', 'Creoles & Pidgins (French-based Other)'),
(94, 'cpp', 'Creoles & Pidgins (Portuguese-based Other)'),
(89, 'cre', 'Cree'),
(93, 'crp', 'Creoles & Pidgins (Other)'),
(217, 'csb', 'Kashubian'),
(96, 'cus', 'Cushitic(Other)'),
(457, 'cym', 'Welsh'),
(98, 'dag', 'Dagbani'),
(99, 'dak', 'Dakota'),
(101, 'dan', 'Danish'),
(104, 'del', 'Delaware'),
(153, 'deu', 'German'),
(106, 'din', 'Dinka'),
(107, 'div', 'Divehi'),
(108, 'doi', 'Dogri'),
(109, 'dra', 'Dravidian(Other)'),
(110, 'dua', 'Duala'),
(112, 'dum', 'Dutch Middle (ca.1050-1350)'),
(113, 'dyu', 'Dyula'),
(114, 'dzo', 'Dzongkha'),
(115, 'efi', 'Efik'),
(116, 'egy', 'Egyptian(Ancient)'),
(117, 'eka', 'Ekajuk'),
(161, 'ell', 'Greek'),
(118, 'elx', 'Elamite'),
(119, 'eng', 'English'),
(120, 'enm', 'English Middle (ca.1100-1500)'),
(123, 'epo', 'Esperanto'),
(122, 'esk', 'Eskimo(Other)'),
(124, 'est', 'Estonian'),
(44, 'eus', 'Basque'),
(125, 'ewe', 'Ewe'),
(126, 'ewo', 'Ewondo'),
(128, 'fan', 'Fang'),
(130, 'fao', 'Faroese'),
(131, 'fas', 'Farsi (Persian)'),
(129, 'fat', 'Fanti (Fante)'),
(133, 'fij', 'Fijian'),
(134, 'fin', 'Finnish'),
(135, 'fiu', 'Finno-Ugrian(Other)'),
(127, 'fng', 'Fanagalo'),
(137, 'fon', 'Fon'),
(139, 'fra', 'French'),
(140, 'frm', 'French Middle (ca.1400-1600)'),
(141, 'fro', 'French Old (842-ca.1400)'),
(142, 'fry', 'Frisian'),
(144, 'ful', 'Fulah'),
(143, 'fur', 'Friulian'),
(146, 'gaa', 'Ga'),
(147, 'gae', 'Gaelic'),
(55, 'gax', 'Borana'),
(150, 'gay', 'Gayo'),
(156, 'gem', 'Germanic(Other)'),
(151, 'gez', 'Geez'),
(157, 'gil', 'Gilbertese'),
(369, 'gla', 'Scottish Gaelic'),
(194, 'gle', 'Irish'),
(148, 'glg', 'Galician'),
(154, 'gmh', 'German Middle High (ca.1050-1500)'),
(155, 'goh', 'German Old High (ca.750-1050)'),
(158, 'gon', 'Gondi'),
(159, 'got', 'Gothic'),
(160, 'grb', 'Grebo'),
(162, 'grc', 'Greek (Ancient)'),
(164, 'grn', 'Guarani'),
(165, 'guj', 'Gujarati'),
(228, 'guz', 'Kisii'),
(166, 'hai', 'Haida'),
(167, 'hat', 'Haitian-Creole'),
(168, 'hau', 'Hausa'),
(169, 'haw', 'Hawaiian'),
(16, 'hbo', 'Ancient Hebrew'),
(374, 'hbs', 'Serbo-Croat'),
(170, 'heb', 'Hebrew'),
(171, 'her', 'Herero'),
(172, 'hil', 'Hiligaynon'),
(173, 'him', 'Himachali'),
(174, 'hin', 'Hindi'),
(176, 'hmn', 'Hmong'),
(175, 'hmo', 'HiriMotu'),
(95, 'hrv', 'Croatian'),
(177, 'hun', 'Hungarian'),
(178, 'hup', 'Hupa'),
(23, 'hye', 'Armenian'),
(180, 'iba', 'Iban'),
(182, 'ibo', 'Igbo'),
(199, 'ijc', 'Izon'),
(208, 'ijn', 'Kalabari'),
(183, 'ijo', 'Ijo'),
(191, 'iku', 'Inuktitut'),
(190, 'ile', 'Interlingue'),
(184, 'ilo', 'Iloko'),
(189, 'ina', 'Interlingua'),
(185, 'inc', 'Indic(Other)'),
(187, 'ind', 'Indonesian'),
(186, 'ine', 'Indo-European(Other)'),
(188, 'inh', 'Ingush'),
(192, 'ipk', 'Inupiak'),
(193, 'ira', 'Iranian(Other)'),
(197, 'iro', 'Iroquoian Languages'),
(181, 'isl', 'Icelandic'),
(198, 'ita', 'Italian'),
(201, 'jav', 'Javanese'),
(200, 'jpn', 'Japanese'),
(203, 'jpr', 'Judeo-Persian'),
(202, 'jrb', 'Judeo-Arabic'),
(214, 'kaa', 'Kara-Kalpak'),
(205, 'kab', 'Kabyle'),
(206, 'kac', 'Kachin'),
(163, 'kal', 'Greenlandic / Kalaallisut'),
(211, 'kam', 'Kamba'),
(212, 'kan', 'Kannada'),
(215, 'kar', 'Karen'),
(216, 'kas', 'Kashmiri'),
(152, 'kat', 'Georgian'),
(213, 'kau', 'Kanuri'),
(218, 'kaw', 'Kawi'),
(220, 'kaz', 'Kazakh'),
(350, 'kek', 'Q''eqchi'' / Kekchi'),
(221, 'kha', 'Khasi'),
(223, 'khi', 'Khoisan(Other)'),
(222, 'khm', 'Khmer (Central)'),
(224, 'kho', 'Khotanese'),
(225, 'kik', 'Kikuyu'),
(226, 'kin', 'Kinyarwanda'),
(227, 'kir', 'Kirghiz'),
(209, 'kln', 'Kalenjin '),
(232, 'kok', 'Konkani'),
(230, 'kom', 'Komi'),
(231, 'kon', 'Kongo'),
(233, 'kor', 'Korean'),
(234, 'kos', 'Kosraean'),
(235, 'kpe', 'Kpelle'),
(236, 'kri', 'Krio'),
(237, 'kro', 'Kru'),
(241, 'kru', 'Kurukh'),
(238, 'kua', 'Kuanyama'),
(239, 'kum', 'Kumyk'),
(240, 'kur', 'Kurdish'),
(242, 'kus', 'Kusaie'),
(243, 'kut', 'Kutenai'),
(244, 'lad', 'Ladino'),
(245, 'lah', 'Lahnda'),
(246, 'lam', 'Lamba'),
(247, 'lao', 'Lao'),
(248, 'lat', 'Latin'),
(249, 'lav', 'Latvian'),
(251, 'lez', 'Lezghian'),
(252, 'lin', 'Lingala'),
(253, 'lit', 'Lithuanian'),
(296, 'lol', 'Mongo'),
(254, 'lom', 'Loma'),
(255, 'loz', 'Lozi'),
(250, 'ltz', 'Letzeburgesch'),
(256, 'lub', 'Luba-Katanga'),
(149, 'lug', 'Ganda'),
(258, 'lui', 'Luiseno'),
(259, 'lun', 'Lunda'),
(260, 'luo', 'Luo (Kenya,Tanzania)'),
(261, 'lus', 'Lushai (Mizo)'),
(257, 'luy', 'Luhya'),
(264, 'mad', 'Madurese'),
(265, 'mag', 'Magahi'),
(281, 'mah', 'Marshallese'),
(266, 'mai', 'Maithili'),
(267, 'mak', 'Makasar'),
(270, 'mal', 'Malayalam'),
(272, 'mam', 'Mam'),
(274, 'man', 'Mandingo'),
(28, 'map', 'Austronesian(Other)'),
(279, 'mar', 'Marathi'),
(283, 'mas', 'Masai'),
(277, 'max', 'Manx'),
(286, 'men', 'Mende'),
(288, 'mer', 'Meru'),
(195, 'mga', 'Irish Middle (900-1200)'),
(290, 'mic', 'Micmac'),
(291, 'min', 'Minangkabau'),
(263, 'mkd', 'Macedonian'),
(295, 'mkh', 'Mon-Khmer(Other)'),
(292, 'mks', 'Mixteco'),
(268, 'mlg', 'Malagasy'),
(271, 'mlt', 'Maltese'),
(275, 'mni', 'Manipuri'),
(276, 'mno', 'Manobolanguages'),
(293, 'moh', 'Mohawk'),
(294, 'mol', 'Moldavian'),
(297, 'mon', 'Mongolian'),
(299, 'mos', 'Mossi'),
(278, 'mri', 'Maori'),
(269, 'msa', 'Malay'),
(300, 'mun', 'Mundalanguages'),
(90, 'mus', 'Creek'),
(282, 'mwr', 'Marwari'),
(63, 'mya', 'Burmese'),
(284, 'myn', 'Mayanlanguages'),
(302, 'nah', 'Nahuatl (Aztec)'),
(315, 'nai', 'NorthAmericanIndian(Other)'),
(303, 'nau', 'Nauru'),
(304, 'nav', 'Navajo'),
(306, 'nbl', 'NdebeleSouth'),
(305, 'nde', 'NdebeleNorth'),
(307, 'ndo', 'Ndongo'),
(308, 'nep', 'Nepali'),
(309, 'new', 'Newari'),
(310, 'nic', 'Niger-Kordofanian(Other)'),
(313, 'niu', 'Niuean'),
(111, 'nld', 'Dutch'),
(318, 'nno', 'Norwegian (Nynorsk)'),
(317, 'nob', 'Norwegian (Bokmal)'),
(314, 'non', 'Norse'),
(316, 'nor', 'Norwegian'),
(397, 'nso', 'SothoNorthern'),
(319, 'nub', 'Nubianlanguages'),
(321, 'nya', 'Nyanja'),
(320, 'nym', 'Nyamwezi'),
(322, 'nyn', 'Nyankole'),
(323, 'nyo', 'Nyoro'),
(324, 'nzi', 'Nzima'),
(325, 'oci', 'Occitan / Langued''Oc'),
(326, 'oji', 'Ojibwe'),
(327, 'ori', 'Oriya'),
(328, 'orm', 'Oromo'),
(329, 'osa', 'Osage'),
(330, 'oss', 'Ossetic'),
(332, 'ota', 'Ottoman'),
(331, 'oto', 'Otomianlanguages'),
(341, 'paa', 'Papuan-Australian(Other)'),
(338, 'pag', 'Pangasinan'),
(334, 'pal', 'Pahlavi'),
(337, 'pam', 'Pampanga'),
(339, 'pan', 'Panjabi'),
(340, 'pap', 'Papiamento'),
(335, 'pau', 'Palauan'),
(343, 'peo', 'PersianOld(ca600-400B.C.)'),
(344, 'phn', 'Phoenician'),
(336, 'pli', 'Pali'),
(346, 'pol', 'Polish'),
(345, 'pon', 'Pohnpeian'),
(347, 'por', 'Portuguese'),
(348, 'pra', 'Prakritlanguages'),
(349, 'pro', 'ProvencalOld(to1500)'),
(102, 'prs', 'Dari'),
(342, 'pus', 'Pashto (Pushto)'),
(204, 'quc', 'K''iche'''),
(351, 'que', 'Quechua'),
(352, 'raj', 'Rajasthani'),
(353, 'rar', 'Rarotongan'),
(355, 'roa', 'Romance(Other)'),
(354, 'roh', 'Rhaeto-Rom (Romansch)'),
(357, 'rom', 'Romany'),
(356, 'ron', 'Romanian'),
(358, 'run', 'Rundi'),
(359, 'rus', 'Russian'),
(364, 'sad', 'Sandawe'),
(365, 'sag', 'Sango'),
(461, 'sah', 'Yakut'),
(398, 'sai', 'SouthAmericanIndian(Other)'),
(360, 'sal', 'Salishanlanguages'),
(361, 'sam', 'SamaritanAramaic'),
(366, 'san', 'Sanskrit'),
(380, 'scn', 'Sicilian'),
(368, 'sco', 'Scots'),
(370, 'sel', 'Selkup'),
(371, 'sem', 'Semitic(Other)'),
(196, 'sga', 'Irish Old (to 900)'),
(376, 'shn', 'Shan'),
(381, 'sid', 'Sidamo'),
(386, 'sin', 'Sinhala (Sinhalese)'),
(388, 'sio', 'Siouanlanguages'),
(387, 'sit', 'Sino-Tibetan'),
(389, 'sla', 'Slavic(Other)'),
(390, 'slk', 'Slovak'),
(391, 'slv', 'Slovenian'),
(362, 'smi', 'Samilanguages'),
(363, 'smo', 'Samoan'),
(377, 'sna', 'Shona'),
(385, 'snd', 'Sindhi'),
(392, 'sog', 'Sogdian'),
(393, 'som', 'Somali'),
(395, 'son', 'Songhai'),
(399, 'sot', 'Southern Sotho / Sesotho'),
(400, 'spa', 'Spanish'),
(11, 'sqi', 'Albanian'),
(367, 'srd', 'Sardinian'),
(372, 'srp', 'Serbian'),
(375, 'srr', 'Serer'),
(312, 'ssa', 'Nilo-Saharan(Other)'),
(378, 'ssw', 'SiSwati (Swazi)'),
(401, 'suk', 'Sukuma'),
(403, 'sun', 'Sundanese'),
(404, 'sus', 'Susu'),
(402, 'sux', 'Sumerian'),
(405, 'swa', 'Swahili'),
(406, 'swe', 'Swedish'),
(407, 'syl', 'Sylheti'),
(408, 'syr', 'Syriac'),
(410, 'tah', 'Tahitian'),
(414, 'tam', 'Tamil'),
(415, 'tat', 'Tatar'),
(416, 'tel', 'Telugu'),
(423, 'tem', 'Timne'),
(417, 'ter', 'Tereno'),
(418, 'tet', 'Tetum'),
(411, 'tgk', 'Tajik'),
(409, 'tgl', 'Tagalog'),
(419, 'tha', 'Thai'),
(421, 'tig', 'Tigre'),
(422, 'tir', 'Tigrinya'),
(424, 'tiv', 'Tivi'),
(425, 'tli', 'Tlingit'),
(413, 'tmh', 'Tamashek'),
(427, 'ton', 'Tonga (Nya)'),
(426, 'tpi', 'Tok Pisin'),
(429, 'tru', 'Truk'),
(430, 'tsi', 'Tsimshian'),
(432, 'tsn', 'Tswana'),
(431, 'tso', 'Tsonga'),
(435, 'tuk', 'Turkmen'),
(433, 'tum', 'Tumbuka'),
(434, 'tur', 'Turkish'),
(14, 'tut', 'Altaic languages'),
(438, 'twi', 'Twi'),
(437, 'tyv', 'Tuvinian'),
(439, 'uga', 'Ugaritic'),
(440, 'uig', 'Uighur'),
(441, 'ukr', 'Ukrainian'),
(443, 'umb', 'Umbundu'),
(444, 'und', 'Undetermined'),
(445, 'urd', 'Urdu'),
(446, 'uzb', 'Uzbek'),
(447, 'vai', 'Vai'),
(449, 'ven', 'Venda'),
(450, 'vie', 'Vietnamese'),
(451, 'vol', 'Volapük'),
(452, 'vot', 'Votic'),
(453, 'wak', 'Wakashanlanguages'),
(454, 'wal', 'Walamo'),
(455, 'war', 'Waray'),
(456, 'was', 'Washo'),
(396, 'wen', 'Sorbian'),
(459, 'wol', 'Wolof'),
(210, 'xal', 'Kalmyk-Oirat'),
(460, 'xho', 'Xhosa'),
(273, 'xmm', 'Manado Malay'),
(462, 'yao', 'Yao'),
(463, 'yap', 'Yapese'),
(465, 'yid', 'Yiddish'),
(262, 'ymm', 'Maay Maay'),
(466, 'yor', 'Yoruba'),
(467, 'zap', 'Zapotec'),
(468, 'zen', 'Zenaga'),
(469, 'zha', 'Zhuang (Chuang)'),
(79, 'zho', 'Chinese'),
(470, 'zul', 'Zulu'),
(471, 'zun', 'Zuni');

-- --------------------------------------------------------

--
-- Table structure for table `language_services`
--

DROP TABLE IF EXISTS `language_services`;
CREATE TABLE IF NOT EXISTS `language_services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lang_service_id` int(11) NOT NULL,
  `lang_service_name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `language_services`
--

INSERT INTO `language_services` (`id`, `lang_service_id`, `lang_service_name`) VALUES
(1, 1, 'Translation'),
(2, 2, 'Checking/editing'),
(3, 3, 'Interpreting, Consecutive'),
(4, 4, 'Interpreting, Simultaneous'),
(5, 5, 'Voiceover'),
(6, 6, 'Summarization'),
(7, 7, 'Education'),
(8, 8, 'Interpreting, Chuchotage/Whispering'),
(9, 9, 'Interpreting, Liaison'),
(10, 10, 'Interpreting, Phone'),
(11, 11, 'Transcription'),
(12, 12, 'Copywriting'),
(13, 13, 'MT post-editing'),
(14, 14, 'Transcreation');

-- --------------------------------------------------------

--
-- Table structure for table `software`
--

DROP TABLE IF EXISTS `software`;
CREATE TABLE IF NOT EXISTS `software` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `software_id` int(11) NOT NULL,
  `software_name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=110 ;

--
-- Dumping data for table `software`
--

INSERT INTO `software` (`id`, `software_id`, `software_name`) VALUES
(1, 46, 'Across'),
(2, 24, 'Adobe Acrobat'),
(3, 36, 'Adobe Illustrator'),
(4, 28, 'Adobe Photoshop'),
(5, 106, 'Aegisub'),
(6, 67, 'Alchemy Publisher'),
(7, 109, 'Amara'),
(8, 40, 'AutoCAD'),
(9, 163, 'Bablic'),
(10, 166, 'BaccS'),
(11, 112, 'Belle Nuit Subtitler'),
(12, 97, 'CafeTran Espresso'),
(13, 115, 'CaptionHub'),
(14, 118, 'CaptionMaker/MacCaption'),
(15, 169, 'Captiz'),
(16, 42, 'Catalyst'),
(17, 172, 'Crowdin'),
(18, 2, 'DejaVu'),
(19, 121, 'DivXLand Media Subtitler'),
(20, 32, 'Dreamweaver'),
(21, 124, 'EZTitles'),
(22, 82, 'Easyling'),
(23, 127, 'FinalSub'),
(24, 76, 'Fluency'),
(25, 30, 'FrameMaker'),
(26, 38, 'Frontpage'),
(27, 17, 'Fusion'),
(28, 175, 'Ginger Page'),
(29, 178, 'GlobalizeIt'),
(30, 100, 'Google Translator Toolkit'),
(31, 59, 'Heartsome'),
(32, 51, 'Helium'),
(33, 11, 'IBM CAT tool'),
(34, 47, 'Idiom'),
(35, 34, 'Indesign'),
(36, 12, 'J-CAT'),
(37, 193, 'LSP.expert'),
(38, 181, 'Lilt'),
(39, 44, 'Lingotek'),
(40, 184, 'Lingviny'),
(41, 53, 'LocStudio'),
(42, 187, 'Localizer'),
(43, 70, 'LogiTerm'),
(44, 190, 'Lokalise'),
(45, 199, 'MOX Gateway'),
(46, 85, 'MadCap Lingo'),
(47, 91, 'MateCat'),
(48, 79, 'MemSource Cloud'),
(49, 15, 'MetaTexis'),
(50, 22, 'Microsoft Excel'),
(51, 64, 'Microsoft Office Pro'),
(52, 20, 'Microsoft Word'),
(53, 196, 'MotionPoint'),
(54, 133, 'MovieCaptioner'),
(55, 6, 'Multicorpora'),
(56, 50, 'Multilizer'),
(57, 202, 'Net-Proxy'),
(58, 136, 'Ninsight Ayato'),
(59, 18, 'OmegaT'),
(60, 14, 'Other'),
(61, 3, 'Other CAT tool'),
(62, 220, 'PROMT'),
(63, 26, 'Pagemaker'),
(64, 205, 'Pairaphrase'),
(65, 8, 'Passolo'),
(66, 208, 'Personal Translator'),
(67, 211, 'PhraseApp'),
(68, 214, 'Plunet BusinessManager'),
(69, 139, 'Poliscript'),
(70, 4, 'Powerpoint'),
(71, 268, 'ProZ.com Translation Center'),
(72, 217, 'Projetex'),
(73, 223, 'Protemos'),
(74, 226, 'Qordoba'),
(75, 229, 'QuaHill'),
(76, 5, 'QuarkXPress'),
(77, 232, 'Redokun'),
(78, 235, 'Rulingo'),
(79, 103, 'SDL Online Translation Editor'),
(80, 1, 'SDL TRADOS'),
(81, 9, 'SDLX'),
(82, 10, 'STAR Transit'),
(83, 238, 'Silver Bullet Suite'),
(84, 241, 'Smartcat'),
(85, 88, 'Smartling'),
(86, 142, 'Subtitle Edit'),
(87, 145, 'Subtitle Editor'),
(88, 148, 'Subtitle Workshop'),
(89, 62, 'Swordfish'),
(90, 247, 'TOM Agency'),
(91, 244, 'Text United Software'),
(92, 154, 'Titlevision Submachine'),
(93, 7, 'TransSuite2000'),
(94, 250, 'Transifex'),
(95, 253, 'Translate'),
(96, 256, 'Translation Exchange'),
(97, 49, 'Translation Workspace'),
(98, 259, 'TranslationProjex'),
(99, 13, 'Uniscape CAT tool'),
(100, 157, 'VoxscribeCC'),
(101, 262, 'WebTranslateIt.com'),
(102, 160, 'Wincaps Q4'),
(103, 94, 'Wordbee'),
(104, 16, 'Wordfast'),
(105, 73, 'XTM'),
(106, 265, 'XTRF Translation Management System'),
(107, 130, 'fiveLoadSub'),
(108, 56, 'memoQ'),
(109, 151, 'titlebee');

-- --------------------------------------------------------

--
-- Table structure for table `specific_disciplines`
--

DROP TABLE IF EXISTS `specific_disciplines`;
CREATE TABLE IF NOT EXISTS `specific_disciplines` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `disc_spec_id` int(11) NOT NULL,
  `disc_spec_name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `disc_spec_id` (`disc_spec_id`,`disc_spec_name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=110 ;

--
-- Dumping data for table `specific_disciplines`
--

INSERT INTO `specific_disciplines` (`id`, `disc_spec_id`, `disc_spec_name`) VALUES
(1, 1, 'Accounting'),
(2, 2, 'Advertising / Public Relations'),
(3, 3, 'Agriculture'),
(4, 5, 'Anthropology'),
(5, 6, 'Architecture'),
(6, 7, 'Art, Arts & Crafts, Painting'),
(7, 8, 'Astronomy & Space'),
(8, 9, 'Automotive / Cars & Trucks'),
(9, 10, 'Aerospace / Aviation / Space'),
(10, 12, 'Biology (-tech,-chem,micro-)'),
(11, 13, 'Botany'),
(12, 15, 'Business/Commerce (general)'),
(13, 16, 'Medical: Cardiology'),
(14, 19, 'Chemistry; Chem Sci/Eng'),
(15, 20, 'Cinema, Film, TV, Drama'),
(16, 23, 'Computers: Hardware'),
(17, 24, 'Computers: Software'),
(18, 25, 'Computers: Systems, Networks'),
(19, 26, 'Construction / Civil Engineering'),
(20, 28, 'Cooking / Culinary'),
(21, 29, 'Cosmetics, Beauty'),
(22, 30, 'Medical: Dentistry'),
(23, 32, 'Economics'),
(24, 33, 'Education / Pedagogy'),
(25, 34, 'Electronics / Elect Eng'),
(26, 35, 'Energy / Power Generation'),
(27, 40, 'Engineering (general)'),
(28, 41, 'Engineering: Industrial'),
(29, 44, 'Environment & Ecology'),
(30, 45, 'Esoteric practices'),
(31, 48, 'Finance (general)'),
(32, 49, 'Fisheries'),
(33, 50, 'Folklore'),
(34, 51, 'Food & Drink'),
(35, 52, 'Forestry / Wood / Timber'),
(36, 53, 'Furniture / Household Appliances'),
(37, 54, 'Games / Video Games / Gaming / Casino'),
(38, 57, 'General / Conversation / Greetings / Letters'),
(39, 58, 'Genealogy'),
(40, 59, 'Geology'),
(41, 60, 'Geography'),
(42, 62, 'Government / Politics'),
(43, 65, 'History'),
(44, 67, 'Human Resources'),
(45, 68, 'IT (Information Technology)'),
(46, 69, 'Insurance'),
(47, 70, 'International Org/Dev/Coop'),
(48, 71, 'Internet, e-Commerce'),
(49, 72, 'Investment / Securities'),
(50, 75, 'Law: Contract(s)'),
(51, 76, 'Law: Patents, Trademarks, Copyright'),
(52, 77, 'Law (general)'),
(53, 80, 'Linguistics'),
(54, 81, 'Livestock / Animal Husbandry'),
(55, 82, 'Poetry & Literature'),
(56, 85, 'Management'),
(57, 87, 'Marketing / Market Research'),
(58, 88, 'Materials (Plastics, Ceramics, etc.)'),
(59, 89, 'Mathematics & Statistics'),
(60, 90, 'Mechanics / Mech Engineering'),
(61, 91, 'Media / Multimedia'),
(62, 92, 'Medical: Pharmaceuticals'),
(63, 93, 'Medical: Instruments'),
(64, 94, 'Medical: Health Care'),
(65, 95, 'Medical (general)'),
(66, 96, 'Metallurgy / Casting'),
(67, 97, 'Metrology'),
(68, 98, 'Military / Defense'),
(69, 99, 'Mining & Minerals / Gems'),
(70, 101, 'Music'),
(71, 103, 'Nuclear Eng/Sci'),
(72, 104, 'Nutrition'),
(73, 105, 'Other'),
(74, 107, 'Paper / Paper Manufacturing'),
(75, 110, 'Petroleum Eng/Sci'),
(76, 112, 'Philosophy'),
(77, 113, 'Photography/Imaging (& Graphic Arts)'),
(78, 114, 'Physics'),
(79, 119, 'Printing & Publishing'),
(80, 120, 'Psychology'),
(81, 122, 'Real Estate'),
(82, 123, 'Religion'),
(83, 124, 'Retail'),
(84, 127, 'SAP'),
(85, 128, 'Science (general)'),
(86, 129, 'Ships, Sailing, Maritime'),
(87, 130, 'Social Science, Sociology, Ethics, etc.'),
(88, 133, 'Sports / Fitness / Recreation'),
(89, 135, 'Surveying'),
(90, 136, 'Law: Taxation & Customs'),
(91, 137, 'Telecom(munications)'),
(92, 138, 'Textiles / Clothing / Fashion'),
(93, 139, 'Tourism & Travel'),
(94, 140, 'Transport / Transportation / Shipping'),
(95, 143, 'Wine / Oenology / Viticulture'),
(96, 146, 'Zoology'),
(97, 147, 'Computers (general)'),
(98, 149, 'Slang'),
(99, 150, 'Names (personal, company)'),
(100, 151, 'Archaeology'),
(101, 152, 'Idioms / Maxims / Sayings'),
(102, 154, 'Journalism'),
(103, 157, 'Manufacturing'),
(104, 158, 'Certificates, Diplomas, Licenses, CVs'),
(105, 159, 'Automation & Robotics'),
(106, 160, 'Genetics'),
(107, 170, 'Patents'),
(108, 173, 'Meteorology'),
(109, 174, 'Safety');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
